namespace paraiso.robo.ModelWeb;

public class Termos
{
    public int Id { get; set; }
    public string termo { get; set; }
}