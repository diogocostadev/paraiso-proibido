namespace paraiso.robo.ModelWeb;

public class Miniaturas
{
    public string Tamanho { get; set; }
    public int Largura { get; set; }
    public int Altura { get; set; }
    public string Src { get; set; }
}